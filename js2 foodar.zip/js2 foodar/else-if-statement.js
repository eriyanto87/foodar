/*Create a variable m and set its value to -10. Write an if/else-if/else-statement. 
The if-statement should check if the value of m is equal to 10.Inside the if-statement, 
you should have a console.log statement that prints “The value of m is equal to 10”. 
The else-if statement should check if the value is less than 0 and even. (
Use the modulus operator to check if a value is even). Inside your else-if statement, you should print 
The value is less than 0 and it is even”. The else-statement should simply print
 “The value is something else”.
NOTE: To write a compound conditional statement, you can use the && or || operators. 
The && operator will compare both values  and execute the associated block if BOTH statements are true and
 || will execute the associated block if either statement is true.*/

 let m = -10;
 if (m === 10){
     console.log("The value of m is equal to 10")
 } else if (m<0 && m%2 === 0) {
     console.log("The value is less than 0 and it is even")
 } else { 
     console.log("The vailue is something else")
 }

