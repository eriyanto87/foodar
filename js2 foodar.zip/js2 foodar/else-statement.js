/*Create a variable s and set its value to 15. Write an else/if-statement. 
The if-statement should check if the value of s is less than or equal to 10. 
Inside the if-statement, you should have a console.log statement that prints 
“The value of s is less than or equal to 10”. The else-statement should simple print 
“The value of s is greater than 10”.
Save your work in a file, else-statement.js*/

let s = 15;
if (s<=10) {
    console.log("The value of s if less than or equal to 10")
} else {
    console.log("The value of s is greater than 10")
}
